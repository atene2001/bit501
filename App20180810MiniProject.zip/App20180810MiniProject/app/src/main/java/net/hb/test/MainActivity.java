package net.hb.test;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends FragmentActivity implements View.OnClickListener
{
    TextView[] tv = new TextView[3];
    ViewPager vp1;
    ViewPagerAdapter vpAdapter;
    Fragment[] fragment = new Fragment[3]; //313라인 참조

    FragmentManager manager;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv[0] = findViewById(R.id.tv1);
        tv[1] = findViewById(R.id.tv2);
        tv[2] = findViewById(R.id.tv3);
        vp1 = findViewById(R.id.vp1);

        fragment[0] = new FirstFragment(); // FirstFragment
        fragment[1] = new SecondFragment(); // SecondFragment
        fragment[2] = new ThreeFragment(); // ThreeFragment

        vpAdapter = new ViewPagerAdapter(this.getSupportFragmentManager());
        vp1.setAdapter(vpAdapter);

        for(int i = 0; i<tv.length; i++)
        {
            tv[i].setOnClickListener(this);
        }
    } // onCreate end

    public void onClick(View v)
    {
        int sel = v.getId();

        if(sel == R.id.tv1)
        {
            vp1.setCurrentItem(0);
        }
        else if(sel == R.id.tv2)
        {
            vp1.setCurrentItem(1);
        }
        else if(sel == R.id.tv3)
        {
            vp1.setCurrentItem(2);
        }
    } // onClick end

    public void callFragment(int iNum)
    {
        vp1.setCurrentItem(iNum);
    }

    class ViewPagerAdapter extends FragmentStatePagerAdapter
    {
        // "Generate..." > "Constructor" 클릭하면 생성. // // 347라인 참조.
        public ViewPagerAdapter(FragmentManager fm)
        {
            super(fm);
        }

        // "Generate..." > "override" 클릭하면 생성.
        @Override
        public Fragment getItem(int position)
        {
            return fragment[position]; // 353라인 참조.
        }

        @Override
        public int getCount()
        {
            return fragment.length; // 358라인 참조.
        }
    } // ViewPagerAdapter(내부클래스) end
} // MainActivity end