package net.hb.test;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ThreeFragment extends android.support.v4.app.Fragment
{
    TextView textView, busNumer;
    String getData;
    int busNumber = 0;
    int busNum = 503;
    String strSrch = busNumber + "";
    int count;

    String serviceUrl = "http://ws.bus.go.kr/api/rest/busRouteInfo/getBusRouteList";
    String serviceUrlRoute = "http://ws.bus.go.kr/api/rest/busRouteInfo/getStaionByRoute";
    String serviceKey = "d8QNMjZBRSclKcQM3n8WO20p%2F1ii%2FmWRAWA8%2F5dcWlMem79RLlU8%2B%2BhGGyOdJFkPn2Hr8xa%2Fr%2BAqEkpelMR5BQ%3D%3D";
//    String strUrl = serviceUrl + "?ServiceKey=" + serviceKey + "&strSrch=" + strSrch; //가져올 정보를 strUrl에 저장함
//    String strUrlRouteserviceUrl + "?ServiceKey=" + serviceKey + "&busRouteId=" + busRouteId; // busRouteId ==> 필요시점마다 가져와서 고정시킬 수 없음.

    Button btnresetcurrent, btnplusbusnum, btnminusbusnum, btnplusbaek, btnminusbaek;
    Button btnFirstCall; // Fragment_First 호출

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_three, container, false);

        textView = v.findViewById(R.id.data);
        busNumer = v.findViewById(R.id.bus);

        btnresetcurrent = v.findViewById(R.id.btnresetcurrent);
        btnplusbusnum = v.findViewById(R.id.btnplusbusnum);
        btnminusbusnum = v.findViewById(R.id.btnminusbusnum);
        btnplusbaek = v.findViewById(R.id.btnplusbaek);
        btnminusbaek = v.findViewById(R.id.btnminusbaek);
        btnFirstCall = v.findViewById(R.id.btnFirstCall);

        resetCurrentBus(v); // 최초 버스정보 호출.

        // 키이벤트 등록
        View.OnClickListener cl = new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                int sel = v.getId();

                if (sel == R.id.btnresetcurrent)
                {
                    resetCurrentBus(v);
                }
                else if (sel == R.id.btnplusbusnum)
                {
                    plusBusNumber(v);
                }
                else if (sel == R.id.btnminusbusnum)
                {
                    minusBusNumber(v);
                }
                else if (sel == R.id.btnplusbaek)
                {
                    plusBaek(v);
                }
                else if (sel == R.id.btnminusbaek)
                {
                    minusBaek(v);
                }
                else if(sel == R.id.btnFirstCall)
                {
                    ((MainActivity)getActivity()).callFragment(0); // FirstFragment로 탭이동.
                }
            }
        };

        btnresetcurrent.setOnClickListener(cl);
        btnplusbusnum.setOnClickListener(cl);
        btnminusbusnum.setOnClickListener(cl);
        btnplusbaek.setOnClickListener(cl);
        btnminusbaek.setOnClickListener(cl);
        btnFirstCall.setOnClickListener(cl);

        return v;
    } // onCreateView end

    public class DownloadWebContent extends AsyncTask<String, Void, String>
    {
        @Override
        protected String doInBackground(String... urls)
        {
            try { return (String) downloadByUrl((String) urls[0]); } catch (IOException e) { return "다운로드 실패"; }
        } // doInBackground end

        protected void onPostExecute(String result)
        {
            //xml 문서를 파싱하는 방법으로 본 예제에서는  Pull Parer 를 사용한다.
            String headerCd = "";
            String busRouteId = "";

            boolean bus_headerCd = false;
            boolean bus_busRouteId = false;

            // textView.append("===== 노선ID =====\n");
            try
            {
                //XmlPullParser 를 사용하기 위해서 XmlPullParserFactory 객체를 생성함
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(true);
                XmlPullParser xmlpp = factory.newPullParser();

                //parser 에 url를 입력함
                xmlpp.setInput(new StringReader(result));

                //parser 이벤트를 저장할 변수 지정
                int eventType = xmlpp.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT)  //문서가 마지막이 아니면
                {
                    if (eventType == XmlPullParser.START_DOCUMENT) { }
                    else if (eventType == XmlPullParser.START_TAG)
                    {
                        String tag_name = xmlpp.getName();
                        if (tag_name.equals("headerCd")) { bus_headerCd = true; }
                        if (tag_name.equals("busRouteId")) { bus_busRouteId = true; }

                    }
                    else if (eventType == XmlPullParser.TEXT)
                    {
                        if (bus_headerCd)
                        {
                            headerCd = xmlpp.getText();
                            bus_headerCd = false;
                        }

                        if (headerCd.equals("0"))
                        {
                            if (bus_busRouteId)
                            {
                                busRouteId = xmlpp.getText();
                                bus_busRouteId = false;
                            }
                        }
                    }
                    else if (eventType == XmlPullParser.END_TAG) { }

                    eventType = xmlpp.next();
                } // while end
            }
            catch (Exception e) { textView.setText(e.getMessage()); }

            String strUrl = serviceUrlRoute + "?ServiceKey=" + serviceKey + "&busRouteId=" + busRouteId;

            DownloadWebContent2 dwc2 = new DownloadWebContent2();
            dwc2.execute(strUrl);
        } //  onPostExecute end

        public String downloadByUrl(String myurl) throws IOException
        {
            //Http 통신: HttpURLConnection 클래스를 활용해 데이터를 얻는다.
            HttpURLConnection conn = null;
            try
            {
                //요청 URL, 전달받은 url string 으로 URL 객체를 만듦
                URL url = new URL(myurl);
                conn = (HttpURLConnection) url.openConnection();

                BufferedInputStream buffer = new BufferedInputStream(conn.getInputStream());
                BufferedReader buffer_reader = new BufferedReader(new InputStreamReader(buffer, "utf-8"));

                String line = null;
                getData = "";
                while ((line = buffer_reader.readLine()) != null)
                {
                    getData += line;
                }
                return getData;
            }
            finally { conn.disconnect(); } //접속 해제
        } // downloadByUrl end
    }

    public class DownloadWebContent2 extends AsyncTask<String, Void, String>
    {
        @Override
        protected String doInBackground(String... urls)
        {
            try { return (String) downloadByUrl((String) urls[0]); } catch (IOException e) { return "다운로드 실패"; }
        }

        protected void onPostExecute(String result)
        {
            String headerCd = "";
            String gpsX = "";
            String gpsY = "";
            String stationNm = "";
            String direction = "";
            String sectSpd = "";

            boolean bus_headerCd = false;
            boolean bus_gpsX = false;
            boolean bus_gpsY = false;
            boolean bus_stationNm = false;
            boolean bus_sectSpd = false;
            boolean bus_direction = false;

            ///// (2) Bus Positions
            textView.append(" == 버스 위치 검색 결과 == \n");

            if(result == null)
            {
                textView.append(" 없음!\n");
                textView.append("-------------------------------------------\n");

                return;
            }

            try
            {
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(true);
                XmlPullParser xmlpp = factory.newPullParser();

                xmlpp.setInput(new StringReader(result));
                int eventType = xmlpp.getEventType();

                count = 0;
                while (eventType != XmlPullParser.END_DOCUMENT)
                {
                    if (eventType == XmlPullParser.START_DOCUMENT)  { }
                    else if (eventType == XmlPullParser.START_TAG)
                    {
                        String tag_name = xmlpp.getName();

                        switch (tag_name)
                        {
                            case "headerCd":
                            {
                                bus_headerCd = true;
                                break;
                            }
                            case "gpsX":
                            {
                                bus_gpsX = true;
                                break;
                            }
                            case "gpsY":
                            {
                                bus_gpsY = true;
                                break;
                            }
                            case "sectSpd":
                            {
                                bus_sectSpd = true;
                                break;
                            }
                            case "stationNm":
                            {
                                bus_stationNm = true;
                                break;
                            }
                            case "direction":
                            {
                                bus_direction = true;
                                break;
                            }
                        }
                    }
                    else if (eventType == XmlPullParser.TEXT)
                    {
                        if (bus_headerCd)
                        {
                            headerCd = xmlpp.getText(); // textView.append("headerCd: " + headerCd + "\n");
                            bus_headerCd = false;
                        }

                        if (headerCd.equals("0"))
                        {
                            if (bus_direction) // 진행방향부터 값을 가져옴.
                            {
                                count = count + 1; // count++;
                                textView.append("-------------------------------------------\n");

                                direction = xmlpp.getText();
                                textView.append("(" + count + ") 진행방향: " + direction + "\n");
                                bus_direction = false;
                            }

                            if (bus_gpsX)
                            {
                                gpsX = xmlpp.getText();
                                textView.append("(" + count + ") gpsX: " + gpsX + "\n");
                                bus_gpsX = false;
                            }

                            if (bus_gpsY)
                            {
                                gpsY = xmlpp.getText();
                                textView.append("(" + count + ") gpsY: " + gpsY + "\n");
                                bus_gpsY = false;
                            }

                            if (bus_stationNm)
                            {
                                stationNm = xmlpp.getText();
                                textView.append("(" + count + ") 정류장이름: " + stationNm + "\n");
                                bus_stationNm = false;
                            }

                            if (bus_sectSpd)
                            {
                                sectSpd = xmlpp.getText();
                                textView.append("(" + count + ") 구간속도: " + sectSpd + "\n");
                                bus_sectSpd = false;
                            }
                        }
                    }
                    else if (eventType == XmlPullParser.END_TAG) { }

                    eventType = xmlpp.next();
                }
            }
            catch (Exception e) { textView.setText(e.getMessage()); }
        }

        public String downloadByUrl(String myurl) throws IOException
        {
            //Java와 Http 통신: HttpURLConnection 클래스를 활용해 데이터를 얻는다.
            HttpURLConnection conn = null;
            BufferedReader buffer_reader;

            try
            {
                //요청 URL, 전달받은 url string 으로 URL 객체를 만듦
                URL url = new URL(myurl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                //결과를 InputStream으로 받아서 INputStreamReader, BufferedReader로 캐스팅한다.
                BufferedInputStream buffer = new BufferedInputStream(conn.getInputStream());
                buffer_reader = new BufferedReader(new InputStreamReader(buffer, "utf-8"));

                String line = null;
                getData = "";
                while ((line = buffer_reader.readLine()) != null)  { getData += line; }

                return getData;
            }
            finally { conn.disconnect(); } //접속 해제
        } // downloadByUrl end
    } // DownloadWebContent2 class end

    public void plusBusNumber(View v)
    {
        busNum += 1;
        strSrch = busNum + "";

        String strUrl = serviceUrl + "?ServiceKey=" + serviceKey + "&strSrch=" + strSrch; //가져올 정보를 strUrl에 저장함

        DownloadWebContent dwc1 = new DownloadWebContent();
        dwc1.execute(strUrl);
        textView.setText("");
        busNumer.setText("");
        busNumer.append("버스번호:" + strSrch); //  + "\n"
    } // plusBusNumber end

    public void minusBusNumber(View v)
    {
        busNum -= 1;
        strSrch = busNum + "";

        String strUrl = serviceUrl + "?ServiceKey=" + serviceKey + "&strSrch=" + strSrch; //가져올 정보를 strUrl에 저장함

        DownloadWebContent dwc1 = new DownloadWebContent();
        dwc1.execute(strUrl);
        textView.setText("");
        busNumer.setText("");
        busNumer.append("버스번호:" + strSrch); // + "\n"
    } // minusBusNumber end

    public void resetCurrentBus(View v)
    {
        //  busNum+=1; // //busNum = 503; // 기본값 = 503;
        strSrch = busNum + "";

        String strUrl = serviceUrl + "?ServiceKey=" + serviceKey + "&strSrch=" + strSrch;//가져올 정보를 strUrl에 저장함

        DownloadWebContent dwc1 = new DownloadWebContent();
        dwc1.execute(strUrl);
        textView.setText("");
        busNumer.setText("");
        busNumer.append("버스번호:" + strSrch); // + "\n"
    } // resetCurrentBus end

    public void plusBaek(View v)
    {
        busNum += 100;
        strSrch = busNum + "";

        String strUrl = serviceUrl + "?ServiceKey=" + serviceKey + "&strSrch=" + strSrch; //가져올 정보를 strUrl에 저장함

        DownloadWebContent dwc1 = new DownloadWebContent();
        dwc1.execute(strUrl);

        textView.setText("");
        busNumer.setText("");
        busNumer.append("버스번호:" + strSrch);// + "\n"
    } // plusBaek end

    public void minusBaek(View v)
    {
        busNum -= 100;
        strSrch = busNum + "";

        String strUrl = serviceUrl + "?ServiceKey=" + serviceKey + "&strSrch=" + strSrch; //가져올 정보를 strUrl에 저장함

        DownloadWebContent dwc1 = new DownloadWebContent();
        dwc1.execute(strUrl);

        textView.setText("");
        busNumer.setText("");
        busNumer.append("버스번호:" + strSrch); // + "\n"
    } // minusBaek end
} // ThreeFragment end
