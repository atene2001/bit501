package net.hb.test;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class FirstFragment extends android.support.v4.app.Fragment
{
    ArrayList<Food> al = new ArrayList<Food>();

    EditText etName, etMsg, etPrice;
    RadioGroup rgHot, rgLike;
    RadioButton rbHotY, rbHotN;
    RadioButton rbLike1, rbLike2, rbLike3, rbLike4, rbLike5;
    Button btnAdd;
    FoodAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        final View v = inflater.inflate(R.layout.fragment_first, container, false);

        // ListView로 과일목록 만들기
        Food fd = new Food();

        al.add(new Food(R.drawable.noodle_rice, "쌀국수", false, "베트남 쌀국수", "9500", 3));
        al.add(new Food(R.drawable.noodle_chinand, "자장면", false, "자장면은 중국집", "6000", 2));
        al.add(new Food(R.drawable.noodle_hotjnd, "쫄면", true, "새콤달콤", "5000", 1));
        al.add(new Food(R.drawable.noodle_partynd, "잔치국수", false, "잔칫날먹기~", "4000", 5));
        al.add(new Food(R.drawable.noodle_hotnd, "비빔국수", true, "오른손으로 비비고~", "5500", 3));
        al.add(new Food(R.drawable.noodle_pastand, "크림파스타", false, "파스타는 크림인가~", "9000", 4));

        //adapter(현재화면의 제어권자, 한행을 그려줄  layout, 다량의 데이터)
        adapter = new FoodAdapter(getContext(), R.layout.food, al); // R.layout.food

        final ListView lv = v.findViewById(R.id.listView1);
        lv.setAdapter(adapter);

        btnAdd = v.findViewById(R.id.btnAdd);

        etName = v.findViewById(R.id.etName);
        etMsg = v.findViewById(R.id.etMsg);
        etPrice = v.findViewById(R.id.etPrice);

        rgHot = v.findViewById(R.id.rgHot);
        rbHotY = v.findViewById(R.id.rbHotY);
        rbHotN = v.findViewById(R.id.rbHotN);

        rgLike = v.findViewById(R.id.rgLike);
        rbLike1 = v.findViewById(R.id.rbLike1);
        rbLike2 = v.findViewById(R.id.rbLike2);
        rbLike3 = v.findViewById(R.id.rbLike3);
        rbLike4 = v.findViewById(R.id.rbLike4);
        rbLike5 = v.findViewById(R.id.rbLike5);

        // 키보드 안보기
        etName.setInputType(0);
        etMsg.setInputType(0);
        etPrice.setInputType(0);

        // 버튼 클릭이벤트
        btnAdd.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                boolean isHot = false;
                String name = "";
                String msg = "";
                String price = "";
                int iLike = 0;

                name = etName.getText().toString();
                if(name.equals("") == true)
                {
                    Toast.makeText(getContext(), "이름을 넣어주세요.", Toast.LENGTH_SHORT).show();
                    etName.requestFocus(); // 포커스 이동
                    return;
                }

                msg = etMsg.getText().toString();
                if(msg.equals("") == true)
                {
                    Toast.makeText(getContext(), "설명을 넣어주세요.", Toast.LENGTH_SHORT).show();
                    etMsg.requestFocus(); // 포커스 이동
                    return;
                }

                price = etPrice.getText().toString();
                if(price.equals("") == true)
                {
                    Toast.makeText(getContext(), "가격을 넣어주세요.", Toast.LENGTH_SHORT).show();
                    etPrice.requestFocus(); // 포커스 이동
                    return;
                }

                //Log.d("btnAdd_onClick", "3:" + rgHot.getCheckedRadioButtonId());
                if(rgHot.getCheckedRadioButtonId() == R.id.rbHotY) { isHot = true; }
                else { isHot = false; }
                Log.d("Food_onClick", "hot : " + isHot);

                switch (rgLike.getCheckedRadioButtonId())
                {
                    case R.id.rbLike1: { iLike = 1;  break; }
                    case R.id.rbLike2: { iLike = 2;  break; }
                    case R.id.rbLike3: { iLike = 3;  break; }
                    case R.id.rbLike4: { iLike = 4;  break; }
                    case R.id.rbLike5: { iLike = 5;  break; }
                }
                Log.d("Food_onClick", "likeKey : " + iLike);

                al.add(new Food(R.drawable.noodle_defalt, name, isHot, msg, price, iLike));
                adapter.notifyDataSetChanged();

                // 추가 후 초기화하기.
                etName.setText("");
                etMsg.setText("");
                etPrice.setText("");
                rbHotN.setChecked(true);
                rbLike1.setChecked(true);
            }
        });

        //리스트뷰는 item클릭리스너 item클릭이벤트 처리
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id)  // AdapterView<?> adapterView, View view, int i, long l
            {
                Log.d("Main_onItemClick", "position : " + position + ", id : " + id);

                Food selFd = (Food) adapter.getItem(position);

                String sHotYN = (selFd.isHot == true)? "매움": "안매움";

                int imgNum = selFd.img;
                String sTitle = selFd.name + "[" + sHotYN + "]";
                String sMsg = selFd.price + "원" + "(선호 : " + selFd.sLikeVal + ")\n" + selFd.msg;

                View dlg = View.inflate(adapterView.getContext(), R.layout.display, null); // FoodActivity.this으로도 쓸 수 있음.
                ImageView poster = dlg.findViewById(R.id.ivPoster);
                poster.setImageResource(imgNum);

                AlertDialog.Builder ab = new AlertDialog.Builder(adapterView.getContext());
                ab.setTitle(sTitle);
                ab.setIcon(R.drawable.noodle_defalt);
                ab.setMessage(sMsg);
                ab.setView(dlg);
                ab.setNegativeButton("close", null);
                ab.show();
            }
        });

        return v;
    } // onCreateView end
} // FirstFragment end

// ArrayList용 클래스
class Food
{
    int img;
    String name = "";
    boolean isHot;
    String msg = "";
    String price = "";
    int iLikeKey = 0;
    String sLikeVal = "";

    public Food() {} // 기존 코드와 호환을 위해서 생성자 작업시 기본생성자가 추가.

    public Food(int img, String name, boolean isHot, String msg, String price, int iLikeKey)
    {
        this.img = img;
        this.name = name;
        this.isHot = isHot;
        this.msg = msg;
        this.price = price;
        this.iLikeKey = iLikeKey;
        this.sLikeVal = getLikeVal(iLikeKey);
    }

    public String getLikeVal(int iLikeKey)
    {
        String sLikeVal = "";
        switch (iLikeKey)
        {
            case 1: { sLikeVal = "별로";  break; }
            case 2: { sLikeVal = "그냥";  break; }
            case 3: { sLikeVal = "보통";  break; }
            case 4: { sLikeVal = "좀땡겨";  break; }
            case 5: { sLikeVal = "자주먹어";  break; }
        }

        return sLikeVal;
    } // getLikeVal end
} // food 클래스 end

class FoodAdapter extends BaseAdapter
{
    Context ctx; // 현재 화면의 제어권자
    int layout; // 한 행을 그려줄 layout
    ArrayList<Food> al; // 다량의 데이터
    LayoutInflater inf; // 화면을 그려줄 때 필요.

    ImageView iv;
    TextView tvName, tvOrigin, tvMsg, tvPrice, tvLike;

    public FoodAdapter() { } // 기본생성자

    public FoodAdapter(Context ctx, int layout, ArrayList<Food> al)
    {
        this.ctx = ctx;
        this.layout = layout;
        this.al = al;
        this.inf = (LayoutInflater) ctx.getSystemService(ctx.LAYOUT_INFLATER_SERVICE);
    } // FruitAdapter 생성자

    @Override
    public int getCount() // 총 데이터의 개수를 리턴.
    {
        return al.size();
    } // getCount end

    @Override
    public Object getItem(int i) // 해당번째의 데이터값
    {
        return al.get(i);
    } // getItem end

    @Override
    public long getItemId(int i) // 해당번째의 고유한 id값
    {
        return i;
    } // getItemId end

    @Override //해당번째의 행에 내용을 셋팅(데이터와 레이아웃의연결관계 정의)
    public View getView(int i, View view, ViewGroup viewGroup)
    {
        if(view == null) { view = inf.inflate(layout, null); }

        iv = view.findViewById(R.id.imageView1);

        tvName = view.findViewById(R.id.tvName);
        tvMsg = view.findViewById(R.id.tvMsg);
        tvPrice = view.findViewById(R.id.tvPirce);
        tvOrigin = view.findViewById(R.id.tvOrigin);
        tvLike = view.findViewById(R.id.tvLike);

        Food fd = al.get(i);

        iv.setImageResource(fd.img);
        tvName.setText(fd.name);

        if (fd.isHot == true)
        {
            tvOrigin.setText("매움");
        }
        else
        {
            tvOrigin.setText("안매움");
        }

        tvMsg.setText(fd.msg);
        tvPrice.setText("가격 : " + fd.price + " 원");

        String sLikeVal = fd.getLikeVal(fd.iLikeKey);
        tvLike.setText(sLikeVal);

        return view;
    } // getView end
} // FoodtAdapter 클래스 end
