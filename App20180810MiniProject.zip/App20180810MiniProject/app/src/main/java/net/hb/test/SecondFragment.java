package net.hb.test;

import android.os.Bundle;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.Toast;

public class SecondFragment extends android.support.v4.app.Fragment
{
    Button btnStart, btnEnd;
    int TotalCnt = 25;
    int CurrCnt = 0;
    Button[] btnNum = new Button[TotalCnt];
    int[] btn={  R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4, R.id.btn5
                , R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9, R.id.btn10
                , R.id.btn11, R.id.btn12, R.id.btn13, R.id.btn14, R.id.btn15
                , R.id.btn16, R.id.btn17, R.id.btn18, R.id.btn19, R.id.btn20
                , R.id.btn21, R.id.btn22, R.id.btn23, R.id.btn24, R.id.btn25
    };
    Chronometer chronometer;
    String sCurrTime = "";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_second, container, false);

        btnStart = v.findViewById(R.id.btnStart);
        btnEnd = v.findViewById(R.id.btnEnd);

        chronometer = v.findViewById(R.id.chronometer);

        for(int i = 0; i<TotalCnt; i++)
        {
            btnNum[i] = v.findViewById(btn[i]);
        }

        // 키이벤트 등록
        View.OnClickListener cl = new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                int sel = v.getId();

                if(sel == R.id.btnStart)
                {
                    CurrCnt = 0;

                    // 난수생성하여 버튼에 넣기
                    int[] randomNum = new int[TotalCnt];

                    for(int i = 0; i < TotalCnt; i++)
                    {
                        randomNum[i] = (int) (Math.random() * (TotalCnt)) + 1;

                        for(int j = 0; j < i; j++)
                        {
                            if(randomNum[i] == randomNum[j])
                            {
                                i--;
                                break;
                            }
                        }
                    }

                    Animation animation;
                    animation = AnimationUtils.loadAnimation(getContext(), R.anim.fadein);

                    for(int i = 0; i < TotalCnt; i++)
                    {
                        btnNum[i].startAnimation(animation);
                        btnNum[i].setText(String.valueOf(randomNum[i]));
                        btnNum[i].setVisibility(v.VISIBLE); // 보이게 함(v.VISIBLE) -> 안보이게 하려면 v.INVISIBLE
                        btnNum[i].setEnabled(true);
                    }

                    chronometer.setBase(SystemClock.elapsedRealtime());
                    chronometer.start();

                    // 타이머 시간제한 이벤트 처리
                    chronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener()
                    {
                        @Override
                        public void onChronometerTick(Chronometer chronometer)
                        {
                            sCurrTime = chronometer.getText().toString();
                            if(sCurrTime.equals("경과시간 : 00:30"))
                            {
                                gameEnd("fail");
                            }
                        }
                    });

                    btnStart.setEnabled(false); // 시작버튼 비활성화
                    btnEnd.setEnabled(true);
                }
                else if(sel == R.id.btnEnd)
                {
                    gameEnd("stop");
                }
                else
                {
                    String sNum = "";
                    int iNum = 0;

                    for(int i = 0; i<TotalCnt; i++)
                    {
                        if(v.getId() == btn[i])
                        {
                            sNum = btnNum[i].getText().toString();

                            if(sNum != null || sNum.equals("") == false)
                            {
                                iNum = Integer.parseInt(sNum);

                                if(iNum == (CurrCnt + 1))
                                {
                                    Animation animation;
                                    animation = AnimationUtils.loadAnimation(getActivity(), R.anim.fadeout);
                                    v.startAnimation(animation);


                                    CurrCnt = CurrCnt + 1;
                                    btnNum[i].setVisibility(v.INVISIBLE); // 보이게 함(v.VISIBLE) -> 안보이게 하려면 v.INVISIBLE
                                    //btnNum[i].setEnabled(false);
                                }
                                else
                                {
                                    Toast.makeText(getActivity(), String.valueOf(CurrCnt+1) + "를 눌러주세요.", Toast.LENGTH_SHORT).show();
                                }
                            }

                            if(CurrCnt == (TotalCnt)) //게임 종료
                            {
                                gameEnd("clear");
                            }
                        }
                    }
                }
            }
        };

        btnStart.setOnClickListener(cl);
        btnEnd.setOnClickListener(cl);

        for(int i = 0; i < TotalCnt; i++)
        {
            btnNum[i].setOnClickListener(cl);
        }

        return v;
    } // onCreateView end

    public void gameEnd(String sVal)
    {
        chronometer.stop();

        btnStart.setEnabled(true); // 시작버튼 활성화
        btnEnd.setEnabled(false);

        for(int i = 0; i < TotalCnt; i++)
        {
            btnNum[i].setEnabled(false);
        }

        if(sVal.equals("stop"))
        {
            Toast.makeText(getActivity(), "게임이 중지되었습니다.", Toast.LENGTH_SHORT).show();
        }
        if(sVal.equals("clear"))
        {
            long second = ((int)(SystemClock.elapsedRealtime() - chronometer.getBase()) / 1000);
            Toast.makeText(getActivity(), second + "초 성공~ 축하합니다.", Toast.LENGTH_SHORT).show();
        }
        else if(sVal.equals("fail"))
        {
            Toast.makeText(getActivity(), "제한시간 30초 경과..실패", Toast.LENGTH_SHORT).show();
        }
    } // gameEnd end
} // SecondFragment end
